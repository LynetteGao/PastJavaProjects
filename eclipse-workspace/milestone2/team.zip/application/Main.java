package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Font;
import javafx.scene.layout.AnchorPane;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;

public class Main extends Application {
	private Stage stage;

	/**
	 * This method design the scene where user can select the number of questions 
	 * he or she would like to do for each topic. 
	 * The number will be used for quiz generation.
	 * Displayed when startQuiz button is pressed.
	 * @return startQuiz scene
	 * @throws FileNotFoundException 
	 */
	private Scene Startquiz() {
		// Creating guidance info label:
    	Label label = new Label("Please enter the number of question you want for each topic:");
    	label.setFont(new Font("Arial", 20));
    	ScrollPane root = new ScrollPane();

    	VBox topic = new VBox();
    	topic.getChildren().addAll(label);
    	topic.setAlignment(Pos.CENTER);
    	
    	// List every topic with a text box of number of questions the user would like to have:
    	for (int i = 0; i < 10; i++) {
        	Label nameLabel = new Label("Topic : " + i);
        	TextField nameField = new TextField();
        	topic.getChildren().addAll(nameLabel, nameField);
    	}
    	
    	// startButton would directs the user to the next scene to formally begin quiz:
    	Button startButton = new Button("Start!");
    	topic.getChildren().addAll(startButton);
    	
    	root.setContent(topic);
            	Button homeButton = new Button("Home");
    	topic.getChildren().addAll(homeButton);
    	homeButton.setOnAction(new EventHandler<ActionEvent>() {
        	public void handle(ActionEvent t) {
            	try {
					stage.setScene(StartScene());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
        	}
    	});
    	
    	
    	root.setMinSize(1500, 1000);

    	return new Scene(root);
	}

	/**
	 * This method designs the scene where the user can add questions 
	 * to the question bank
	 * @return addQuestion scene
	 */
	private Scene AddQuestion() {
    	BorderPane root = new BorderPane();
    	Button homeButton = new Button("Home");
    	root.setCenter(homeButton);
    	homeButton.setOnAction(new EventHandler<ActionEvent>() {
        	public void handle(ActionEvent t) {
            	try {
					stage.setScene(StartScene());
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
        	}
    	});
    	//root.getChildren().add(homeButton);
    	return new Scene(root);

	}

	/**
	 * This method designs the startQuiz scene, 
	 * displayed when buttonStart button is pressed
	 * @return Home scene
	 * @throws FileNotFoundException
	 */
	protected Scene StartScene() throws FileNotFoundException {

		// Create label of the title:
    	Label CS400Label = new Label("\nQuiz Generator\n ");
    	CS400Label.setFont(new Font("Arial", 60));// change font
    	CS400Label.setTextFill(Color.DARKGREY);// change color
    	CS400Label.setMaxWidth(Double.MAX_VALUE);
    	AnchorPane.setLeftAnchor(CS400Label, 0.0);
    	AnchorPane.setRightAnchor(CS400Label, 0.0);
    	CS400Label.setAlignment(Pos.CENTER); // center-aligned
    	
    	// Create label of the intro:
    	Label intro = new Label("Welcome to Quiz Generator! " 
    			+"\nA brighter academic future starts here"
    			+"\n(Yea who am I kidding)\n");
    	intro.setFont(new Font("Arial", 15));// change font
    	intro.setTextFill(Color.DARKGREY);// change color
    	intro.setMaxWidth(Double.MAX_VALUE);
    	AnchorPane.setLeftAnchor(intro, 0.0);
    	AnchorPane.setRightAnchor(intro, 0.0);
    	intro.setAlignment(Pos.CENTER);
    	
    	// Create BorderPane: 
    	BorderPane root = new BorderPane();
    	//root.setMinSize(1500, 1000);
    	
    	ObservableList<String> topics = FXCollections.observableArrayList("Topic 1", "Topic 2", "Topic 3");
    	@SuppressWarnings({ "rawtypes", "unchecked" })
    	final ComboBox comboBox = new ComboBox(topics);

    	// Create the 2 buttons on the first scene:
    	Button buttonAdd = new Button(); 
    	Button buttonStart = new Button();	 
    	
    	// buttonAdd directs to the scene of adding questions
    	buttonAdd.setText("Add quiz");
    	buttonAdd.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	public void handle(ActionEvent t) {
            	stage.setScene(AddQuestion());
        	}
    	});

    	// buttonStart directs to the scene of doing quiz
    	buttonStart.setText("Start quiz");
    	buttonStart.setOnAction(new EventHandler<ActionEvent>() {

        	@Override
        	public void handle(ActionEvent t) {
            	stage.setScene(Startquiz());
        	}
    	});
    	
    	// Designing button's style: 
    	
    	DropShadow shadow = new DropShadow();
    	//Adding the shadow when the mouse cursor is on
    	buttonStart.addEventHandler(MouseEvent.MOUSE_ENTERED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	            buttonStart.setEffect(shadow);
    	        }
    	});
    	//Removing the shadow when the mouse cursor is off
    	buttonStart.addEventHandler(MouseEvent.MOUSE_EXITED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	            buttonStart.setEffect(null);
    	        }
    	});
    	//Adding the shadow when the mouse cursor is on
    	buttonAdd.addEventHandler(MouseEvent.MOUSE_ENTERED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	            buttonAdd.setEffect(shadow);
    	        }
    	});
    	//Removing the shadow when the mouse cursor is off
    	buttonAdd.addEventHandler(MouseEvent.MOUSE_EXITED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	            buttonAdd.setEffect(null);
    	        }
    	});
    	// Setting shadow of the buttons:
    	buttonAdd.setStyle("-fx-background-color: linear-gradient(to bottom, derive(-fx-text-box-border, -10%), -fx-text-box-border),linear-gradient(from 0px 0px to 0px 5px, derive(-fx-control-inner-background, -9%), -fx-control-inner-background);");
    	buttonStart.setStyle("-fx-background-color: linear-gradient(to bottom, derive(-fx-text-box-border, -10%), -fx-text-box-border),linear-gradient(from 0px 0px to 0px 5px, derive(-fx-control-inner-background, -9%), -fx-control-inner-background);");
    	
    	// Put buttons into vBox:
    	VBox vBox = new VBox(10);
    	vBox.setAlignment(Pos.CENTER);
    	vBox.getChildren().addAll(CS400Label, intro, buttonAdd, buttonStart);
    	root.setCenter(vBox);

    	// Setting button size and locations: 
    	buttonAdd.setTranslateX(0);
    	buttonAdd.setTranslateY(50);
    	buttonAdd.setPrefWidth(300);
    	buttonAdd.setPrefHeight(60);

    	buttonStart.setTranslateX(0);
    	buttonStart.setTranslateY(50);
    	buttonStart.setPrefWidth(300);
    	buttonStart.setPrefHeight(60);

    	// Setting logo image: 
    	Image logoPic = new Image(new FileInputStream("application/logo.PNG"));
    	ImageView logo = new ImageView(logoPic);
    	logo.setFitWidth(800);
    	logo.setFitHeight(1000);
    	
    	//root.setTop(CS400Label);
    	//root.setCenter(intro);
    	root.setLeft(logo);
    	return new Scene(root, 700, 400, Color.GREY);
	}

	/**
	 * This method is the driver of displaying all Scenes:
	 */
	@Override
	public void start(Stage primaryStage) {
    	try {
        	stage = primaryStage;
        	stage.setMaximized(true);
        	Scene scene = StartScene();
        	primaryStage.setScene(scene);
        	primaryStage.setTitle("Quiz Generator");
        	primaryStage.show();

    	} catch (Exception e) {
        	e.printStackTrace();
    	}
	}

	public static void main(String[] args) {
    	launch(args);
	}
}



