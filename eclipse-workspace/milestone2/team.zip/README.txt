README

Course: cs400
Semester: Spring 2019
Project name: Milestone 2 QuizGenerator
Author:
1. Roxin Liu, Lec004, rliu227@wisc.edu
2. Lynette Gao, Lec004, qgao23@wisc.edu
3. Sivakorn Sanguanmoo, Lec004, sanguanmoo@wisc.edu
4. Xiaxin Li, Lec004, xli685@wisc.edu
5. Yajie Wang, Lec002, wang929@wisc.edu


Notes or comments to the grader:
There are 2 scenes, the first one is the home scene.
If you click the button "Start quiz", it will direct you to the next scene
where the user can select the number of questions for each topic.

Thanks for your grading.